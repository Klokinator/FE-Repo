# [\[Archer-Reskin\] \[M\] Der's Wil](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FInfantry%20-%20(Bow)%20Archers%20and%20Hunters%2F%5BArcher-Reskin%5D%20%5BM%5D%20Der's%20Wil%2F5.%20Bow)

## Bow

| Still | Animation |
| :---: | :-------: |
| ![Bow still](./Bow_000.png) | ![Bow](./Bow.gif) |

## Credit

Original animation by IS.

Archer Variant by DerTheVaporeon.
