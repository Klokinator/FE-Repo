# [\[Ephraim-Variant\] \[M\] T1 Vanilla Repack +Weapons]

## Credit

Vanilla animation by IS.

Additional weapons (???) by DerTheVaporeon, Pikmin1211.

Staff by ZoramineFae.
	
## Sword

| Still | Animation |
| :---: | :-------: |
| ![Sword still](./Sword_000.png) | ![Sword animation](./Sword.gif) |
