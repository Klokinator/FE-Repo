# [Dragon Breath Animations by L95 and 7743](https://git.io/JElfQ) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://git.io/JElJN)



## Credits

Credits are currently in the process of being implemented fully. Please use the names within {} in the title until the work is complete.

