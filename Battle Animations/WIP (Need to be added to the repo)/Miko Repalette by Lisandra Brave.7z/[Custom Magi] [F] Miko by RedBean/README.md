# [\[Custom Magi\] \[F\] Miko by RedBean](./) [![Downlod](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FMagi%20-%20Special%2F%5BCustom%20Magi%5D%20%5BF%5D%20Miko%20by%20RedBean)
## Credits

Made by Red Bean.

Scripted by Dolkar.

## Weapons

| <b>Magic</b><br/><img alt="Magic animation" src="./6.%20Magic/Magic.gif"/> | <b>Staff</b><br/><img alt="Staff animation" src="./7.%20Staff/Staff.gif"/> |
| :---: | :---: |
