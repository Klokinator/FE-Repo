Original spritesheet by RenOokami.

Bow/unarmed by Knabepicer