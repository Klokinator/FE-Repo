Japanese :

私はこのアニメーションの効果音をFE8に合わせているのでFE7で利用する場合は
自分でFE8から効果音を移植してください。
もし、どうしても移植方法がわからない場合は
制作者の私(SHYUTERz)へ直接問い合わせるか、この動画↓を参考にしてください。
                                           https://youtu.be/N_bUMjmEraU

---------------------------------------------------------------------------
English :

This animation uses quite a bit of the sound effects from FE8, 
so if you want to use them in FE7 
you will need to port the sound effects from FE8 yourself.
If you really don't know how to port them, you can use
Contact me (SHYUTERz), the creator, directly or take a look at this video.
　　　　　　　　　　　　　　　　　　→ https://youtu.be/N_bUMjmEraU

---------------------------------------------------------------------------
Credit :

SHYUTERz = Leader

HIROTO   = He did some research on the bugs, added some missing images, etc.

SHIRMER  = She doesn't have access to a computer, 
           but she shared her ideas for motion and palettes with us.

※Please do not put her name on Credit.
　If you use this animation, please put only my name in the Credit.