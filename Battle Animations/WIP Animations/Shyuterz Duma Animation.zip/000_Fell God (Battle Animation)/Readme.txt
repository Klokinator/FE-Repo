Japanese:

変身アニメーションを利用する場合は
Patchの戦闘変身パッチ(Install)を導入しましょう。

-------------------------------------------------------------------------
English:

If you want to use the transformation animation, 
install Battle Transforming (Installer) from Patch.