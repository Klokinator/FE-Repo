2021/07/18

Credit: SHYUTERz & SHYUTERs Team(HIROTO etc)
--------------------------------------------
注意点(Japanese)

１：
ver, CSA_CreatorのMage Knight Army (魔導軍隊)は、本来なら240×64であるはずですが
フェードに関する制作ミスで、わざと264×64で抽出しています。
なので、一回インポートしたらもう抽出して再度インポートしないようにしてください。
もしそれをやっちゃうと、フェードやフラッシュの画像が勝手に削除されてしまってめちゃくちゃになります。

２：
Air Forces (飛行部隊)のRanged (間接)だけヒット直後の地形バグを修正する黒描画がないのは
単純にOBJの限界サイズをオーバーしてしまうため、無しにしてます。

以上
------------------------------------------------------------------------------------------------------------------------
Precautions (English)

1:
The "Mage Knight Army (魔導軍隊)" in "ver, CSA_Creator" should be 240x64, but due to a production error regarding the fade, 
it was intentionally extracted at 264x64.
So once you have imported it, please do not extract it and import it again.
If you do that, the fade effect and the image for the flash will be deleted by itself and this animation will be ruined. 
So please be careful.

2:
Only "Ranged (間接)" in "Air Forces (飛行部隊)" doesn't have the black drawing to fix the terrain bug right after the hit, 
because it would exceed the OBJ limit size.

That's all.