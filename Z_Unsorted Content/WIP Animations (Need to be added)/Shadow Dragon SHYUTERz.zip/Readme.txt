2021/08/28

Credit: SHYUTERz
-------------------------------------------------------------------------------------------------

Japanese:
バグや制限を修正しました。
以前のバージョンだと間接モーションでフリーズしましたが、
霧モーションの位置を下げて枚数を減らすことで修正することができました。

ただし、かなり複雑な手順で作ったり
超微調整を行ったので、私以外の者が編集することを禁じます。
編集する場合は必ず私に許可を得るようにしてください。
※Hack Romで使用するのは自由です。


English:
All bugs and limitations have been fixed.
In previous versions, ranged would freeze, 
but this could be fixed by 
lowering the position of the fog motion and reducing the number of sheets.

However, since I used a rather complicated procedure to create it and made super fine adjustments, 
it is forbidden for anyone other than me to edit it.
If you want to edit it, please make sure to ask my permission.
※You are free to use it in Hack Rom.