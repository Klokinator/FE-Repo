2021/08/16

Credit: SHYUTERz
-------------------------------------------------------------------------------------------

Jpanese:
L95さんが制作したドラゴンの戦闘アニメーションをベースにして作ったので、
このアニメーションを利用する際は必ずその戦闘アニメーションと併用してください。

English:
I based this animation on the dragon battle animation created by L95, 
so be sure to use it in conjunction with L95's battle animation when using this animation.