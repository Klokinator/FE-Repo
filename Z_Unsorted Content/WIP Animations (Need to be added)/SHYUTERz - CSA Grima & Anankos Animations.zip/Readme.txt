ver, Japanese:
二体のGBAFE風の新ラスボスがようやく完成しました。
だいぶ前から慎重に取り組んでいたので約1ヶ月くらいかかりました。
かなり大型で複雑なアニメーションなので、これらを完璧に利用(実装)するにはかなりの時間が必要となります。
さらに、あまりに大容量のアニメーション(FEditorAdv及びCSA_Creator)を取り込みすぎると
全ての魔法アニメーション(エレシュキガルなどの既存のアニメーションも含む)の動作がラグくなりますので、
本当に必要な方もしくは容量に余裕のある方のみご利用くださいませ。 
F2U, F2Eではありますが、極限にタイミングなどを微調整しているので
あまりいじりすぎると魔法とバトルアニメーションとのバランスが崩れて
全てが乱れる場合があるので編集はオススメはしません。
ただし、魔法アニメーションだけを利用するには全然問題ないのでそれはご自由にご利用ください。

ver, English:
I finally finished the animations for the two new GBAFE-style final bosses. 
I started working on them carefully a long time ago, so it took me about a month. 
These are rather large and complex animations, 
so it will take quite a bit of your time and knowledge to fully implement them into your Hack Rom. 
Furthermore, if you import too many large animations (FEditorAdv and CSA_Creator) into your Hack Rom, 
all magic animations (including existing animations such as Ereshkigal) will run very slowly. 
Although these animations are F2U and F2E, 
I have fine-tuned the timing and other aspects of the animations very delicately, 
so I don't recommend editing them too much as it may upset the balance between the magic and battle animations. 
However, if you only want to use the magic animations, there is no problem at all, so feel free to do so.


By SHYUTERz
(2021/04/01)